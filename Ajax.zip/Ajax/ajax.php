<?php
echo "Hello from the server!";
?>
